<?php
$host="localhost";
$dbase="zainab";
$user="root";
$pass="Alquds1";
?>