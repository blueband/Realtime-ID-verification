<style>
.image {
    /* max-width:235px;
    max-height:235px;
    width: auto;
    height: auto;
    display: block; */
    /* width: 100%; Image container is now full-width */
}

.image img {
    margin: 20px auto; /* "auto" will center block elements */
    display: block; /* Set images to be "block" so they obey our auto margin */
    max-width:213px;
    max-height:213px;
    width: auto;
    height: auto;
    display: block;
}
</style>

<div class="image">
    <img src="../admin/student_img/12_78res_98765.jpg">
    <img src="../admin/student_img/12_78res_98765.png">
</div>
